import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

        @Test
        void testAddTaskWithUniqueID() {
            TaskService service = new TaskService();

            Task task1 = new Task("123", "Task One", "This is a test");
            Task task2 = new Task("123", "Task Two", "this is a test!!!!");

            service.addTask(task1);

            assertThrows(IllegalArgumentException.class, () ->service.addTask(task2));
        }

        @Test
        void testDeletingTask() {
            TaskService service = new TaskService();
            Task task = new Task("642", "Test Task", "This is a test");

            service.addTask(task);
            service.deleteTask("642");

            assertThrows(IllegalArgumentException.class, () ->
                    service.updateTaskName("642", "Updated"));
        }

        @Test
        void testUpdatingTaskDetails() {
            TaskService service = new TaskService();
            Task task = new Task("123", "Test Task", "This is a test");

            service.addTask(task);

            service.updateTaskName("123", "Updated Task");
            service.updateTaskDescription("123", "Updated description");

            assertEquals("Updated Task", task.getName());
            assertEquals("Updated description", task.getDescription());
        }

        @Test
        void testUpdatingTaskThatDoesNotExist() {
            TaskService service = new TaskService();

            assertThrows(IllegalArgumentException.class, () ->
                    service.updateTaskName("999", "Updated"));
        }
    }