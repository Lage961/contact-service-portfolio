import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// AI helped learn how to use JUnit test : https://chatgpt.com/share/6ab55927-788c-83ea-b172-7f7096c51aa7
public class TaskTest {

    @Test
    void testValidTask() {
        Task task = new Task("5421", "Test Task", "Test description");

        assertEquals("5421", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("Test description", task.getDescription());
    }

    @Test
    void testTaskFieldRequirements() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Test", "Description"));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("12345678901", "Test", "Description"));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", null, "Description"));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", "123456784555345678901", "Description"));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", "Test", null));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", "Test",
                        "123456789012345655555534567890123456789012345678901"));
    }

    @Test
    void testTaskUpdates() {
        Task task = new Task("123", "Test Task", "Description");

        task.setName("Update task");
        task.setDescription("Update description");
        assertEquals("Update task", task.getName());
        assertEquals("Update description", task.getDescription());
    }
}