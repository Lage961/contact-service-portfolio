import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @Test
    void testAppointmentCreation() {
        Appointment appointment =
                new Appointment("1234567890", futureDate(), "Doctor appointment");

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, futureDate(), "Description"));
    }

    @Test
    void testAppointmentIdCannotBeLongerThan10Characters() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", futureDate(), "Description"));
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("123", null, "Description"));
    }

    @Test
    void testAppointmentDateCannotBeInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("123", pastDate, "Description"));
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("123", futureDate(), null));
    }

    @Test
    void testDescriptionCannotBeLongerThan50Characters() {
        String longDescription = "123456789012345678901234567890123456789012345678901";

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("123", futureDate(), longDescription));
    }

    @Test
    void testAppointmentIdCannotBeUpdated() {
        Appointment appointment =
                new Appointment("123", futureDate(), "Description");

        assertEquals("123", appointment.getAppointmentId());
    }

    @Test
    void testDescriptionCanBeUpdated() {
        Appointment appointment =
                new Appointment("123", futureDate(), "Old description");

        appointment.setDescription("New description");

        assertEquals("New description", appointment.getDescription());
    }
}