import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment("123", futureDate(), "Doctr appointment");

        service.addAppointment(appointment);

        assertEquals(appointment, service.getAppointment("123"));
    }

    @Test
    void testAddAppointmentWithDuplicateId() {
        AppointmentService service = new AppointmentService();

        Appointment appointment1 =
                new Appointment("123", futureDate(), "First appointment");

        Appointment appointment2 =
                new Appointment("123", futureDate(), "Second appointment");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(appointment2));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment("123", futureDate(), "Doctor appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("123");

        assertNull(service.getAppointment("123"));
    }

    @Test
    void testDeleteAppointmentThatDoesNotExist() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteAppointment("123"));
    }
}